import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEmailAccountSchema, insertEmailSchema } from "@shared/schema";
import { setupAuth } from "./auth";

function requireAuth(req: Express.Request, res: Express.Response, next: Express.NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  app.get("/api/email-accounts", requireAuth, async (req, res) => {
    const accounts = await storage.getEmailAccounts(req.user!.id);
    res.json(accounts);
  });

  app.post("/api/email-accounts", requireAuth, async (req, res) => {
    const parsed = insertEmailAccountSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid email account data" });
    }
    try {
      const account = await storage.createEmailAccount(req.user!.id, parsed.data);
      res.status(201).json(account);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  app.delete("/api/email-accounts/:id", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid ID" });
    }
    await storage.deleteEmailAccount(id, req.user!.id);
    res.sendStatus(204);
  });

  app.get("/api/emails/:accountId", requireAuth, async (req, res) => {
    const accountId = parseInt(req.params.accountId);
    if (isNaN(accountId)) {
      return res.status(400).json({ error: "Invalid account ID" });
    }
    const emails = await storage.getEmails(accountId, req.user!.id);
    res.json(emails);
  });

  app.post("/api/emails", requireAuth, async (req, res) => {
    const parsed = insertEmailSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid email data" });
    }
    const email = await storage.createEmail(parsed.data);
    res.status(201).json(email);
  });

  app.get("/api/domains", requireAuth, async (_req, res) => {
    const domains = await storage.getDomains();
    res.json(domains);
  });

  const httpServer = createServer(app);
  return httpServer;
}