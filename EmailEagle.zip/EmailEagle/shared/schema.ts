import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailAccounts = pgTable("email_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  address: text("address").notNull().unique(),
  domain: text("domain").notNull(),
  alias: text("alias"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const domains = pgTable("domains", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  available: boolean("available").default(true),
});

export const emails = pgTable("emails", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => emailAccounts.id),
  from: text("from").notNull(),
  to: text("to").notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEmailAccountSchema = createInsertSchema(emailAccounts)
  .pick({
    address: true,
    domain: true,
    alias: true,
  })
  .extend({
    password: z.string().min(6, "Password must be at least 6 characters"),
  });

export const insertEmailSchema = createInsertSchema(emails).pick({
  accountId: true,
  from: true,
  to: true,
  subject: true,
  content: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type EmailAccount = typeof emailAccounts.$inferSelect;
export type InsertEmailAccount = z.infer<typeof insertEmailAccountSchema>;
export type Email = typeof emails.$inferSelect;
export type InsertEmail = z.infer<typeof insertEmailSchema>;
export type Domain = typeof domains.$inferSelect;