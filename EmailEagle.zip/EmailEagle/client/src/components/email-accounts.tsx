import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { EmailAccount } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { Mail, Trash2 } from "lucide-react";
import { Button } from "./ui/button";

interface EmailAccountsProps {
  accounts: EmailAccount[];
  isLoading: boolean;
  selectedAccount: EmailAccount | null;
  onSelectAccount: (account: EmailAccount) => void;
}

export function EmailAccounts({
  accounts,
  isLoading,
  selectedAccount,
  onSelectAccount,
}: EmailAccountsProps) {
  const { toast } = useToast();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/email-accounts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/email-accounts"] });
      toast({
        title: "Account deleted",
        description: "The email account has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Your Accounts</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Accounts ({accounts.length}/50)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {accounts.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            No email accounts yet
          </div>
        ) : (
          accounts.map((account) => (
            <div
              key={account.id}
              className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                selectedAccount?.id === account.id
                  ? "bg-primary/5 border-primary"
                  : "hover:bg-accent"
              }`}
              onClick={() => onSelectAccount(account)}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">
                      {account.address}@{account.domain}
                    </p>
                    {account.alias && (
                      <p className="text-sm text-muted-foreground">
                        {account.alias}
                      </p>
                    )}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteMutation.mutate(account.id);
                  }}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
